import java.util.ArrayList;
import java.util.List;

class YouutubeMusicInitaitor {
    private List<MusicListner> listeners = new ArrayList<MusicListner>();

    public void addListener(MusicListner toAdd) {
        listeners.add(toAdd);

    }
    public void playSongs(){
        System.out.println("Playing Songs!!");
        for(MusicListner h1 : listeners)
            h1.listenMusic();
    }

}
