
class Test {

    public static void main(String[] args) {
        YouutubeMusicInitaitor youutubeMusicInitaitor = new YouutubeMusicInitaitor();
        BluetoothSpeakers bluetoothSpeakers = new BluetoothSpeakers();
        HeadPhones headPhones = new HeadPhones();

        youutubeMusicInitaitor.addListener(bluetoothSpeakers);
        youutubeMusicInitaitor.addListener(headPhones);
        youutubeMusicInitaitor.playSongs();


    }

}
