public interface MusicListner {
 void listenMusic();
}
