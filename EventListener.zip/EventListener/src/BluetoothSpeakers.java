public class BluetoothSpeakers implements MusicListner {
    public void listenMusic(){
        System.out.println("Listeneing Music from Speaker");
    }
}
